<?php
/**
 * MSK Token-G — Auto-Update Server (InfinityFree)
 * Root endpoint — status check
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

echo json_encode([
    'status' => 'MSK Token-G Update Server',
    'online' => true,
    'host'   => 'InfinityFree'
]);
